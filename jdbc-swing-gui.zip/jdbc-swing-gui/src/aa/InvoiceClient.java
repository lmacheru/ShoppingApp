package aa;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;

public class InvoiceClient extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JTable table1 = new JTable();
	public static JTextField textField_1;
	JComboBox comboBox = new JComboBox();

	
	public InvoiceClient() {
		setType(Type.POPUP);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(493, 500);

		Object[] columns = {"ProductName","Price" ,"vatCharged","IncVat"};
		DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(columns);
		table1.setShowGrid(false);

		// set the model to the table
		table1.setModel(model);

		// Change A JTable Background Color, Font Size, Font Color, Row Height
		table1.setBackground(Color.LIGHT_GRAY);
		table1.setForeground(Color.black);
		Font font = new Font("", 1, 12);

		table1.setFont(font);
		table1.setRowHeight(15);

		JLabel lblProductname = new JLabel("ProductName");
		lblProductname.setBounds(10, 47, 86, 14);

		JLabel label = new JLabel("");
		label.setBounds(56, 269, 0, 0);
		label.setBackground(Color.GREEN);
		label.setForeground(Color.BLACK);

		
		//===================================================
		JScrollPane pane = new JScrollPane(table1);
		pane.setEnabled(false);
		pane.setBounds(10, 99, 442, 163);
		getContentPane().setLayout(null);
		getContentPane().add(pane);
		
		JButton btnadd = new JButton("Add to chart");
		btnadd.setBounds(10, 278, 150, 29);

		
		comboBox.setBounds(96, 44, 135, 20);

		// ============================================================================
		// connection to the data base
		shopDatabase.loadEmbeddedDriver();
		shopDatabase.ConnectToDB();
		
		shopDatabase.viewIncomboBox(comboBox);
		
		
		getContentPane().setLayout(null);
		getContentPane().add(pane);
		getContentPane().add(lblProductname);
		getContentPane().add(comboBox);
		getContentPane().add(btnadd);
		getContentPane().add(label);
		
		JLabel lblQuantity = new JLabel("Quantity Available");
		lblQuantity.setBounds(10, 72, 110, 16);
		getContentPane().add(lblQuantity);
		
		JLabel lblProductDiscription = new JLabel("Product discription");
		lblProductDiscription.setBounds(246, 47, 110, 14);
		getContentPane().add(lblProductDiscription);
		
		textField_1 = new JTextField();
		textField_1.setBounds(354, 44, 98, 20);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnRemoveFromChart = new JButton("remove from chart");
		btnRemoveFromChart.setBounds(10, 318, 150, 29);
		getContentPane().add(btnRemoveFromChart);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(363, 427, 89, 23);
		getContentPane().add(btnCancel);
		
		JButton btnPrintInvoice = new JButton("Print invoice");
		btnPrintInvoice.setBounds(302, 273, 150, 29);
		getContentPane().add(btnPrintInvoice);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(133, 66, 49, 22);
		getContentPane().add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
	
		
		/// ==========================================================================
		// checks whether stock is below or about the one in the data base
		btnadd.addActionListener(new ActionListener() {//<=====add chart btn
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnadd) {		
						shopDatabase.add(textField_1,comboBox, model);
						shopDatabase.viewQuantity(textArea);				
				}
			};
		});
		
		// ========================================================================================
		comboBox.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			if(e.getSource()==comboBox){
				textField_1.setText(comboBox.getSelectedItem()+ "");			
			}
		}
	});
	
		//removes items from the User chart
		btnRemoveFromChart.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(table1.getSelectedRow()==-1){//-1 means if row is not selected it showed show error message
					JOptionPane.showMessageDialog(btnRemoveFromChart,"please select item to delete");
				}else
					
					shopDatabase.viewReturned(textField_1,comboBox, model);
					shopDatabase.viewQuantity(textArea);	
					
			}
		});
	
		//btn to cancel and close  the windows
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();//function to close the Frame
			}
		});
		
		//btn to print invoice and show subtotal
		btnPrintInvoice.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				if(e.getSource()==btnPrintInvoice){
					
					shopDatabase.viewTotal(model);
					shopDatabase.totalprice=0;
					shopDatabase.includeVat=0;
				}
			}
		});
	}
	
	public static void main(String[] args) {

		new InvoiceClient().setVisible(true);
		;
	}
}
