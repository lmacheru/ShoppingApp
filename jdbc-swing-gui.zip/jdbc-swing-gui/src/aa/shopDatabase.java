package aa;


import java.awt.TextArea;
import java.awt.TextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class shopDatabase {
	private static final String driverString = "org.apache.derby.jdbc.EmbeddedDriver";
	private static final String protocol = "jdbc:derby:";
	static String dataBaseName = "grosseri";
	static Connection conn = null;
	static Statement s;
	static String tableName = "shop_stock";
	public static int totalprice=0;
	public static double includeVat=0;
	
	public static void loadEmbeddedDriver() {
		try {
			Class.forName(driverString).newInstance();
			System.out.println("Derby Driver has been loaded\n");
		} catch (Exception e) {
			System.err.println(e.getMessage() + " FAILED!! ");
			System.exit(0);
		}
	}
	//=========================================================================================================	
	//Creating Database then Connecting to it
	//=========================================================================================================	
	public static void createDbAndConnect() {
		System.out.println("Creating " + dataBaseName);
		try {
			conn = DriverManager.getConnection(protocol + dataBaseName +";create=true" );
			System.out.println(dataBaseName + " Has Been Created");
			System.out.println("Connection to " + dataBaseName + " Has been Established");
			createShopTable();
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}
	//=========================================================================================================	
	//Connection to an existing data base that is mostly used by the user
	//=========================================================================================================	
	public static void ConnectToDB() {
		System.out.println("Connecting to " + dataBaseName);
		try {
			conn = DriverManager.getConnection(protocol + dataBaseName);
			System.out.println("Connection to " + dataBaseName + " Has been Established");
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}
	
	//=========================================================================================================	
	//Creates the shops database table
	//=========================================================================================================	
	public static void createShopTable() {

		try {
			s = conn.createStatement();
			s.execute("Drop table "+tableName);
			s.execute("Create table " + tableName + " (i_id INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY(START WITH 1,INCREMENT BY 1), "
					+ "item_desc varchar(50),unit_price Decimal,Quantity int)");

			System.out.println("Table " + tableName + " has been created");
		} catch (SQLException e) {
			System.err.println(e.getMessage());
		}
	}

	//=========================================================================================================	
	//Insert items to the databse table
	//=========================================================================================================	
	public static void insertItem(String item,Double unitPrice,int quantity) {
		int updates = 0;
		
		System.out.println("Inserting items...");
		try {
			s = conn.createStatement();
			s.execute("INSERT INTO shop_stock (item_desc,Unit_price,Quantity)" + " VALUES ('"+item +"R "+unitPrice+"," + quantity+")");
			updates += s.getUpdateCount();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		System.out.println(updates + " inserts made in table " + tableName);
		System.out.println();
	}
	//=========================================================================================================	
	//Adding available stock to  the comboBox of the User
	//=========================================================================================================	
	public static void viewIncomboBox(JComboBox comboBox){
		String st = ""; 
		try {
			Statement s = conn.createStatement();
			ResultSet rs;
			rs =s.executeQuery("SELECT Distinct * FROM "+tableName);
			while(rs.next()){
				String item = rs.getString("item_desc");
				double unitPrice = rs.getDouble("unit_price");
				int quantity = rs.getInt("Quantity");
			//	comboBox.addItem("");
				comboBox.addItem(item);
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}
			//=========================================================================================================
			//adding the items to the chart and then make changes to the database by removing stock added to chart
			//=========================================================================================================	
	public static void add(JTextField txt,JComboBox comboBox,DefaultTableModel md){
		String st = ""; 
		try {
			Statement s = conn.createStatement();
			ResultSet rs;
			Object[] row = new Object[5];
			double includeVAT=0;
		
			rs =s.executeQuery("SELECT * FROM "+tableName +" WHERE "+"item_desc ="+"'"+txt.getText().toString()+"'");
		
			while(rs.next()){	
				if(rs.getInt("Quantity")<=0){
					JOptionPane.showMessageDialog(txt, "We are out of stock now");
				}
				
				else{
				row[0] = rs.getString("item_desc");
				row[1] = rs.getDouble("unit_price");

				double Vatcharged=rs.getDouble("unit_price")*0.14;
				row[2] = (Vatcharged);
				
				includeVAT+=Double.parseDouble(row[1].toString());
				row[3] = (includeVAT)+(Vatcharged);
				md.addRow(row);
				totalprice += Double.parseDouble((row[1].toString()));
			}
				
		}		
		s.execute("Update "+tableName
				+ " Set Quantity = Quantity - 1 "
				+ "WHERE item_desc = "+"'"+txt.getText()+ "'" );
		
		
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}
			//==================================================================================
			//When removing items on chart the change are added back to the database
			//==================================================================================	
	public static void viewReturned(JTextField txt,JComboBox comboBox,DefaultTableModel md){
		String st = ""; 
		try {
			Statement s = conn.createStatement();
			ResultSet rs;
			Object[] row = new Object[6];
			double includeVAT=0;
		
			rs =s.executeQuery("SELECT * FROM "+tableName +" WHERE "+"item_desc ="+"'"+txt.getText().toString()+"'");
		
			while(rs.next()){	
					
				row[0] = rs.getString("item_desc");
				row[1] = rs.getDouble("unit_price");

				double Vatcharged=rs.getDouble("unit_price")*0.14;
				row[2] = (Vatcharged);
				
				includeVAT+=Double.parseDouble(row[1].toString());
				row[3] = (includeVAT)+(Vatcharged);
				row[4] =rs.getInt("Quantity");
				
				totalprice -= Double.parseDouble((row[1].toString()));
				md.removeRow(0);
				
				
		}		
		s.execute("Update "+tableName
				+ " Set Quantity = Quantity + 1 "
				+ "WHERE item_desc = "+"'"+txt.getText()+ "'" );
		
		
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}
	
			//=================================================================	
			//shows the admin all the stock available in the shop's database 
			//=================================================================
	public static void viewAvailable(DefaultTableModel model){
		String st = ""; 
		try {
			Statement s = conn.createStatement();
			ResultSet rs;
			rs =s.executeQuery("SELECT * FROM "+tableName);
			while(rs.next()){
				Object[] row = new Object[4];
				row[0] = rs.getString("item_desc");
				row[1] = "R "+rs.getDouble("unit_price");
				row[2] = rs.getInt("Quantity");
			  
				model.addRow(row);
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}
	
			//================================================================================
			//Admin deletes stock from the Databse
			//================================================================================
			
	public static void deleteStock(JTextField item){
				String st = ""; 
				try {
			Statement s = conn.createStatement();
			ResultSet rs;
			Object[] row = new Object[5];
			double includeVAT=0;
		
			rs =s.executeQuery("SELECT * FROM "+tableName +" WHERE "+"item_desc ="+"'"+item.getText().toString()+"'");
		
			s.execute("delete from "+tableName
				+ " WHERE item_desc = "+"'"+item.getText()+ "'" );
		
		
				} catch (SQLException e) {
		
					e.printStackTrace();
				}
			}
	
			//===============================================================================
			//Admin updates stock in the business if there is no more stock
			//===============================================================================
	public static void UpdateStock(JTextField item,JTextField Quan,JTextField Newprice){
		String st = ""; 
		try {
			Statement s = conn.createStatement();
			ResultSet rs;
			Object[] row = new Object[5];
			double includeVAT=0;
		
			rs =s.executeQuery("SELECT * FROM "+tableName +" WHERE "+"item_desc ="+"'"+item.getText().toString()+"'");
		
			s.execute("Update "+tableName
				+ " Set Quantity =  Quantity +"+Quan.getText() +", unit_price = "+Newprice.getText()
				+ "WHERE item_desc = "+"'"+item.getText()+ "'" );
		
		
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}
	
	
	
			//================================================================================
			//this shows the subtotal of all the items bought
			//===============================================================================
	
	public static void viewTotal(DefaultTableModel model){
		String st = ""; 
		
		try {
			Statement s = conn.createStatement();
			ResultSet rs;
			rs =s.executeQuery("SELECT * FROM "+tableName);
			includeVat=totalprice * 1.14;
			
				Object[] row = new Object[4];
				row[0]= "TotalPriceExcVAT";
				row[1] = totalprice;
				row[2] = "TotalPriceIncVAT";
				row[3] = includeVat;
				model.addRow(row);
				
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}
	
			//========================================================================
			//Updates the user with the remaining stock in the shop 
			//========================================================================
	public static void viewQuantity(JTextArea textArea){
		String Q = ""; 
		int count=1;
		try {
			Statement s = conn.createStatement();
			ResultSet rs;
			rs =s.executeQuery("SELECT  DISTINCT * FROM "+tableName + " WHERE  item_desc = '" + InvoiceClient.textField_1.getText() + "'"  );
					textArea.setText("quantity");
			while(rs.next()){			
				int quantity = rs.getInt("Quantity");
				
					Q+= ""+quantity;
					textArea.setText(Q);
				count++;
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}
}

