package aa;

import java.awt.Color;

import java.awt.Font;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;

import java.awt.event.MouseAdapter;

import java.awt.event.MouseEvent;

import javax.swing.JButton;

import javax.swing.JFrame;

import javax.swing.JScrollPane;

import javax.swing.JTable;

import javax.swing.JTextField;

import javax.swing.table.DefaultTableModel;
import javax.swing.text.View;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.JComboBox;

public class JTableRow {

	public static void main(String[] args) {
		
		new JTableRow();
	}
	public JTableRow(){
		
		
		// create JFrame and JTable

		JFrame frame = new JFrame();
		JTable table = new JTable();

		// create a table model and set a Column Identifiers to this model
		Object[] columns = {"ProductName", "Price", "Quantity" };
		DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(columns);

		// set the model to the table
		table.setModel(model);

		// Change A JTable Background Color, Font Size, Font Color, Row Height
		table.setBackground(Color.LIGHT_GRAY);
		table.setForeground(Color.black);
		Font font = new Font("", 1, 12);

		table.setFont(font);
		table.setRowHeight(15);
		JTextField textProductName = new JTextField();
		JTextField textQuantity = new JTextField();
		JTextField textPrice = new JTextField();

		// create JButtons
		JButton btnAdd = new JButton("Add");
		JButton btnDelete = new JButton("Delete");
		JButton btnUpdate = new JButton("Update");

		textProductName.setBounds(88, 238, 100, 25);
		textQuantity.setBounds(88, 310, 100, 25);
		textPrice.setBounds(88, 274, 100, 25);
		btnAdd.setBounds(214, 238, 100, 25);
		btnUpdate.setBounds(214, 274, 100, 25);
		btnDelete.setBounds(214, 310, 100, 25);

		// create JScrollPane
		JScrollPane pane = new JScrollPane(table);
		pane.setBounds(15, 37, 387, 163);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(pane);
		frame.getContentPane().add(textProductName);
		frame.getContentPane().add(textQuantity);
		frame.getContentPane().add(textPrice);

		// add JButtons to the jframe
		frame.getContentPane().add(btnAdd);
		frame.getContentPane().add(btnDelete);
		frame.getContentPane().add(btnUpdate);
		
		JButton btnClose = new JButton("close");
		btnClose.setBounds(324, 342, 73, 23);
		frame.getContentPane().add(btnClose);
		
		JLabel lblItemname = new JLabel("itemName");
		lblItemname.setBounds(15, 238, 72, 25);
		frame.getContentPane().add(lblItemname);
		
		JLabel lblQuantity = new JLabel("Quantity");
		lblQuantity.setBounds(20, 310, 72, 25);
		frame.getContentPane().add(lblQuantity);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setBounds(15, 274, 60, 25);
		frame.getContentPane().add(lblPrice);
		
		JButton btnViewDatabase = new JButton("view database");
		btnViewDatabase.setBounds(283, 202, 118, 25);
		frame.getContentPane().add(btnViewDatabase);
		
		JLabel lblStockAvailableIn = new JLabel("Stock available in the business");
		lblStockAvailableIn.setBounds(123, 11, 221, 25);
		frame.getContentPane().add(lblStockAvailableIn);

		
		
		// create an array of objects to set the row data
		Object[] row = new Object[4];
		
		// button add row
		btnAdd.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			
				row[0] = textProductName.getText();
				row[1] = textPrice.getText();
				row[2] = textQuantity.getText();
				
				if(textProductName.getText().length()==0|| textQuantity.getText().length()==0||textPrice.getText().length()==0){
					JOptionPane.showMessageDialog(btnAdd, "Can not add empty fields");
				}else
				{
					//add row to the model
					String item=textProductName.getText();
					Double unitprice=Double.parseDouble(textPrice.getText());
					int Quantity=Integer.parseUnsignedInt(textQuantity.getText());
					
					shopDatabase.insertItem( item, unitprice, Quantity);
					model.addRow(row);
				}		
			}				
		});

		// button remove row
		btnDelete.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				if(textProductName.getText().length()==0){
					JOptionPane.showMessageDialog(btnDelete, "Can not delete empty fields...Please write the name of product in textfield");
				}else{
					shopDatabase.deleteStock(textProductName);
					JOptionPane.showMessageDialog(btnDelete, textProductName.getText()+" has been updated");
					
				}
				
			}
		});
		
		// button update row
		btnUpdate.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(textProductName.getText().length()==0|| textQuantity.getText().length()==0||textPrice.getText().length()==0){
					JOptionPane.showMessageDialog(btnUpdate, "Can not update empty fields");
				}else
				{
					shopDatabase.UpdateStock(textProductName,textQuantity,textPrice);
					JOptionPane.showMessageDialog(btnUpdate, textProductName.getText()+" has been updated");
					frame.dispose();
					
					new JTableRow();
					
					
				}
			}	
		});
		
		
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
			}
		});
		
		//btn to view everything available on the database
		btnViewDatabase.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e) {				
				frame.dispose();
				new JTableRow();
			}
		});	
		
		shopDatabase.loadEmbeddedDriver();
		shopDatabase.ConnectToDB();
		//shopDatabase.createDbAndConnect();
		shopDatabase.viewAvailable(model);
		
		frame.setSize(423, 415);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

	}
}
